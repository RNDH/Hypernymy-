"""
Script to handle multiple texts.

Usage:
    text_to_conll_cli (-i <input> | --input=<input>)
        (-o <output> | --output=<output>)
        [-m <model> | --model=<model>]
    text_to_conll_cli (-h | --help)

Options:
    -i <input> --input=<input>
        A directory of text files
    -o <output> --output=<output>
        The directory to save the parsed CoNLL-X files
    -m <model> --model=<model>
        The name BERT model used to parse (to be placed in the model directory) [default: catib]
    -h --help
        Show this screen.

import os
from pathlib import Path
from camel_tools.utils.charmap import CharMapper
from src.classes import TextParams
from src.conll_output import save_to_file, text_tuples_to_string
from src.data_preparation import get_tagset, parse_text
from src.initialize_disambiguator.disambiguator_interface import get_disambiguator
from src.utils.model_downloader import get_model_name
from docopt import docopt
from pandas import read_csv
from transformers.utils import logging
import time
logging.set_verbosity_error()

arguments = docopt(__doc__)

def main():
    root_dir = Path(__file__).parent
    model_path = root_dir/"models"
    
    # camel_tools import used to clean text
    arclean = CharMapper.builtin_mapper("arclean")

    #
    ### Get clitic features
    #
    clitic_feats_df = read_csv(root_dir / 'data/clitic_feats.csv')
    clitic_feats_df = clitic_feats_df.astype(str).astype(object) # so ints read are treated as string objects
    

    #
    ### cli user input ###
    #
    input_path = arguments['--input']
    output_path = arguments['--output']
    parse_model = arguments['--model']


    #
    ### Set up parsing model 
    # (download defaults models, and get correct model name from the models directory)
    #
    model_name = get_model_name(parse_model, model_path=model_path)
    
    # 
    ### get tagset (depends on model)
    #
    tagset = get_tagset(parse_model)
    
    disambiguator = get_disambiguator("bert", "r13")
    
    #
    ### main code ###
    #
    for root, _, files in os.walk(input_path):
        for text_file in files:
            print(f'processing {text_file}')
            lines = []
            s_time=time.time()
            with open(f'{root}/{text_file}', 'r') as f:
                lines = [line for line in f.readlines() if line.strip()]
            file_type_params = TextParams(lines, model_path/model_name, arclean, disambiguator, clitic_feats_df, tagset, "")
            parsed_text_tuples = parse_text("text", file_type_params)

            new_name = '.'.join((text_file.split('.')[:-1])) + '.conllx'
            
            save_to_file(
                text_tuples_to_string(parsed_text_tuples, file_type='text', sentences=lines),
                Path(output_path) / new_name
            )
            e_time=time.time()
	    print("time for file",(e_time-s_time/3600))
if __name__ == '__main__':
    main()
    """
#python handle_multiple_texts.py -i /media/randah/0b60ddf9-4b0c-4b37-afaf-93898a41f63a/Dataset/ -o /media/randah/0b60ddf9-4b0c-4b37-afaf-93898a41f63a/Dataset/parse_out/ -m catib
import os
import time
import logging
import pandas as pd
import networkx as nx
from pathlib import Path
from multiprocessing import Pool, cpu_count
from camel_tools.utils.charmap import CharMapper
from src.classes import TextParams
from src.data_preparation import get_tagset, parse_text
from src.initialize_disambiguator.disambiguator_interface import get_disambiguator
from src.utils.model_downloader import get_model_name
from docopt import docopt
from pandas import read_csv

# Set up logging
LOG_FILE = "processing.log"
logging.basicConfig(
    level=logging.INFO, 
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE),  # Save logs to file
        logging.StreamHandler()         # Print logs to console
    ]
)

logging.info("Script started.")

arguments = docopt(__doc__)

# Define paths for each relation
relations = {
    "attributes": {
        "pairs": "/media/randah/0b60ddf9-4b0c-4b37-afaf-93898a41f63a/Dataset/attributes_pairs_search.txt",
        "sentences": "/media/randah/0b60ddf9-4b0c-4b37-afaf-93898a41f63a/Dataset/text_tparse/file_paths_attributes_search.txt"
    },
    "holonyms": {
        "pairs": "/media/randah/0b60ddf9-4b0c-4b37-afaf-93898a41f63a/Dataset/holonyms_pairs_search.txt",
        "sentences": "/media/randah/0b60ddf9-4b0c-4b37-afaf-93898a41f63a/Dataset/text_tparse/file_paths_holonyms_search.txt"
    },
    "meronyms": {
        "pairs": "/media/randah/0b60ddf9-4b0c-4b37-afaf-93898a41f63a/Dataset/meronyms_pairs_search.txt",
        "sentences": "/media/randah/0b60ddf9-4b0c-4b37-afaf-93898a41f63a/Dataset/text_tparse/file_paths_meronyms_search.txt"
    },
    "synonyms": {
        "pairs": "/media/randah/0b60ddf9-4b0c-4b37-afaf-93898a41f63a/Dataset/synonyms_pairs_search.txt",
        "sentences": "/media/randah/0b60ddf9-4b0c-4b37-afaf-93898a41f63a/Dataset/text_tparse/file_paths_synonyms_search.txt"
    },
    "hypernyms": {
        "pairs": "/media/randah/0b60ddf9-4b0c-4b37-afaf-93898a41f63a/Dataset/hypernyms_pairs_search.txt",
        "sentences": "/media/randah/0b60ddf9-4b0c-4b37-afaf-93898a41f63a/Dataset/text_tparse/file_paths_hypernyms_search.txt"
    }
}

def parse_and_process_file(file_info):
    """Parses a text file using CAMeL and writes results directly to CSV (memory-efficient)."""
    relation, file_path, word_pairs, model_path, model_name, arclean, disambiguator, clitic_feats_df, tagset, output_dir = file_info

    logging.info(f'Starting {file_path} for relation: {relation} on process {os.getpid()}')

    start_time = time.time()
    
    output_file = f"{output_dir}/{relation}_dependency_paths.csv"
    is_new_file = not Path(output_file).exists()  # Check if file exists (needed for headers)

    try:
        with open(file_path, "r", encoding="utf-8") as f, open(output_file, 'a', encoding='utf-8', newline='') as csvfile:
            csv_writer = csv.writer(csvfile)

            # Write CSV header if it's a new file
            if is_new_file:
                csv_writer.writerow(["word1", "word2", "pos1", "pos2", "dep_path", "relation"])

            for line in f:  # Read and process one sentence at a time (low memory usage)
                sentence = line.strip()
                if not sentence:
                    continue

                # Parse the sentence using CAMeL Tools
                file_type_params = TextParams([sentence], model_path / model_name, arclean, disambiguator, clitic_feats_df, tagset, "")
                parsed_text_tuples = parse_text("text", file_type_params)

                # Convert parsed output to DataFrame-like structure (without storing it in RAM)
                for parsed_sentence in parsed_text_tuples:
                    dep_graph = build_dependency_graph(parsed_sentence)

                    for _, row in word_pairs.iterrows():
                        word1, word2 = row["word1"], row["word2"]
                        if (word1 in parsed_sentence["Word"].values) and (word2 in parsed_sentence["Word"].values):
                            path = extract_dependency_path(dep_graph, parsed_sentence, word1, word2)
                            if path:
                                csv_writer.writerow([
                                    word1, word2,
                                    parsed_sentence[parsed_sentence["Word"] == word1]["POS"].values[0],
                                    parsed_sentence[parsed_sentence["Word"] == word2]["POS"].values[0],
                                    path, relation
                                ])
                
                csvfile.flush()  # Ensure data is written to disk frequently

    except Exception as e:
        logging.error(f"Error processing {file_path}: {e}")

    elapsed_time = (time.time() - start_time) / 60
    logging.info(f"Finished {file_path} for {relation} in {elapsed_time:.2f} minutes.")


def main():
    root_dir = Path(__file__).parent
    model_path = root_dir / "models"

    # Load Arabic text cleaner
    arclean = CharMapper.builtin_mapper("arclean")

    # Load clitic features
    clitic_feats_df = read_csv(root_dir / 'data/clitic_feats.csv')
    clitic_feats_df = clitic_feats_df.astype(str).astype(object)

    # CLI User Inputs
    output_path = arguments['--output']
    parse_model = arguments['--model']

    # Set up parsing model
    model_name = get_model_name(parse_model, model_path=model_path)
    tagset = get_tagset(parse_model)
    disambiguator = get_disambiguator("mle", "r13")

    # Collect files for multiprocessing
    files = []
    for relation, paths in relations.items():
        word_pairs = pd.read_csv(paths["pairs"], names=["word1", "word2"])
        with open(paths["sentences"], "r", encoding="utf-8") as f:
            sentence_files = [line.strip() for line in f.readlines() if line.strip()]
        
        for file_path in sentence_files:
            files.append((relation, file_path, word_pairs, model_path, model_name, arclean, disambiguator, clitic_feats_df, tagset, output_path))

    logging.info(f"Processing {len(files)} files across {len(relations)} relations using {cpu_count() // 2} cores...")

    with Pool(processes=max(1, cpu_count() // 2)) as pool:  # Use half the available cores to reduce RAM usage
        pool.map(parse_and_process_file, files)

    logging.info("All files processed.")

if __name__ == '__main__':
    main()

